Tabbing around the page should reveal a mixed up tab order. Read through the
`index.html` and see if there are any places where elements may be in the wrong
order. If something looks out of place see if you can fix it so the tab order
works as expected. If you get stuck you can refer to the `solution` directory.
