The buttons on this page don’t currently have focus styles, making them pretty
much useless to a keyboard user. With your new CSS knowledge, try using  the
:focus pseudo-class to give these buttons interesting focus states.
